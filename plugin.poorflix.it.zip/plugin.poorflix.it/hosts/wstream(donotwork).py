#!/usr/bin/python

from requests import post
from bs4 import BeautifulSoup
from scrapers.utils import headers

class Metadata:
	def __init__(self):
		self.logo = None
		self.icon = None

def get_video(url):
	ids = (
		url
		.split("/")[-1]
		.split(".")[0]
	)

	post_data = {
		"videox": ids
	}

	body = post(
		url, post_data,
		headers = headers
	).text

	links = (
		body
		.split("sources: [\"")[2]
		.split("\"],")[0]
	)

	video_url = eval("[\"%s\"]" % links)
	return video_url